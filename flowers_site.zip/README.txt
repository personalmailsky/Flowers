FLOWERS SITE - Exported Website
-------------------------------

Files:
- index.html

How to publish for FREE at:
  https://yourusername.github.io/flowers

Option A: GitHub Project Page (recommended)
1. Create a new GitHub repository named 'flowers' (or any name you like).
2. Upload all files from this ZIP to the repository root on the main branch.
3. Go to Settings -> Pages (or Pages in the left sidebar).
4. Under 'Build and deployment', select:
     - Branch: main
     - Folder: / (root)
   Then save.
5. Wait a few minutes. Your site will be available at:
   https://yourusername.github.io/flowers
   (replace 'yourusername' with your GitHub username)

Option B: GitHub Pages using 'username.github.io' repo
1. Create a new repository named exactly 'yourusername.github.io'.
2. Upload index.html into the repository root.
3. The site will be live at:
   https://yourusername.github.io

Notes:
- If you want the site at https://yourdomain.com later, buy a domain and point it to GitHub Pages.
- To change the recipient Formspree endpoint, edit the 'endpoint' variable in the script inside index.html.

Good luck selling the site! If you want, I can:
- Rename files to match a specific GitHub username
- Add a LICENSE file
- Add a simple payment button (Stripe test)
- Create a one-click deploy to Vercel/Netlify